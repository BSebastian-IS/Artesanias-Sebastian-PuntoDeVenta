import {table,esc,button} from '../lib/utils.js';
export function clientes(s){return `<div class="panel"><div class="section-toolbar"><p>Directorio de clientes.</p>${button('+ Nuevo cliente','new-customer','','primary')}</div>${table(['Nombre','Teléfono','Correo','Acciones'],s.db.customers.map(c=>[esc(c.name),esc(c.phone),esc(c.email),button('Editar','edit-customer',c.id)]))}</div>`;}
