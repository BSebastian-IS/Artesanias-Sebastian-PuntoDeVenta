import {test} from 'node:test';import assert from 'node:assert/strict';import {totals,parseCSV,esc} from '../src/lib/utils.js';
test('Descuento, impuesto y centavos',()=>assert.deepEqual(totals([{price:30,quantity:3}],10,16),{subtotal:90,discount:9,tax:12.96,total:93.96}));
test('CSV respeta comas, saltos de línea y comillas',()=>assert.deepEqual(parseCSV('sku,name\r\n1,"Llave, metal"\r\n2,"Texto ""doble""\nnuevo"'),[['sku','name'],['1','Llave, metal'],['2','Texto "doble"\nnuevo']]));
test('Texto de producto no puede inyectar HTML',()=>assert.equal(esc('<img onerror="x">'),'&lt;img onerror=&quot;x&quot;&gt;'));
