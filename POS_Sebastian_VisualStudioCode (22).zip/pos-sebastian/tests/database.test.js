import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
const ADMIN='00000000-0000-4000-8000-000000000001';
const OTHER='00000000-0000-4000-8000-000000000002';
const CASHIER='00000000-0000-4000-8000-000000000003';
const db=new PGlite();
await db.exec(`create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,email text);insert into auth.users values('${ADMIN}','admin@test.com'),('${OTHER}','otro@test.com'),('${CASHIER}','cajero@test.com');create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('test.uid',true),'')::uuid$$;grant usage on schema auth to authenticated;grant execute on function auth.uid() to authenticated;`);
await db.exec(await readFile(new URL('../supabase/01_esquema.sql',import.meta.url),'utf8'));
await db.exec(await readFile(new URL('../supabase/02_usuarios_por_correo.sql',import.meta.url),'utf8'));
await db.exec(await readFile(new URL('../supabase/03_cajeros_por_sucursal.sql',import.meta.url),'utf8'));
async function user(id){await db.query(`select set_config('test.uid',$1,false)`,[id]);await db.exec('set role authenticated');}
async function rpc(a,p){return (await db.query('select public.pos_action($1,$2::jsonb) result',[a,JSON.stringify(p)])).rows[0].result;}
await user(ADMIN);
const b=await rpc('bootstrap',{name:'Tienda pruebas',user_name:'Admin'});
const branch=(await db.query('select * from public.branches order by name limit 1')).rows[0].id;
const p1=await rpc('product',{business_id:b,sku:'A',name:'Producto A',price:30,cost:10,min_stock:2});
const p2=await rpc('product',{business_id:b,sku:'B',name:'Producto B',price:50,cost:20,min_stock:2});
await rpc('stock',{business_id:b,branch_id:branch,product_id:p1,quantity:10,reason:'Entrada'});
await rpc('stock',{business_id:b,branch_id:branch,product_id:p2,quantity:1,reason:'Entrada'});
const shift=await rpc('open_shift',{business_id:b,branch_id:branch,opening_cash:100});
const payload={business_id:b,branch_id:branch,shift_id:shift,request_id:crypto.randomUUID(),items:[{product_id:p1,quantity:2},{product_id:p2,quantity:1}],discount_percent:10,payment:'cash',received:120};
test('Venta atómica, total calculado por servidor e idempotencia',async()=>{const id=await rpc('sale',{...payload,total:1});assert.equal(id,payload.request_id);await rpc('sale',payload);const sales=(await db.query('select * from public.sales')).rows;assert.equal(sales.length,1);assert.equal(Number(sales[0].total),99);assert.equal(Number(sales[0].change),21);assert.equal((await db.query('select * from public.sale_items')).rows.length,2);const stock=(await db.query('select quantity from public.inventory where product_id=$1',[p1])).rows[0];assert.equal(stock.quantity,8);});
test('Una venta con inventario insuficiente revierte todas sus escrituras',async()=>{await assert.rejects(rpc('sale',{...payload,request_id:crypto.randomUUID(),items:[{product_id:p1,quantity:3},{product_id:p2,quantity:2}]}),/Existencias/);assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[p1])).rows[0].quantity,8);assert.equal((await db.query('select * from public.sales')).rows.length,1);});
test('Rechaza carrito vacío, cantidades negativas, pago insuficiente y duplicados',async()=>{for(const patch of [{items:[]},{items:[{product_id:p1,quantity:-1}]},{items:[{product_id:p1,quantity:1}],received:0},{items:[{product_id:p1,quantity:1},{product_id:p1,quantity:1}]}])await assert.rejects(rpc('sale',{...payload,request_id:crypto.randomUUID(),...patch}));assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[p1])).rows[0].quantity,8);});
test('Cancelación restaura stock una sola vez y elimina ingreso de caja',async()=>{await rpc('cancel_sale',{business_id:b,id:payload.request_id});await rpc('cancel_sale',{business_id:b,id:payload.request_id});assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[p1])).rows[0].quantity,10);assert.equal((await db.query('select status from public.sales')).rows[0].status,'cancelled');});
test('Caja, retiros, diferencia y bloqueo después del corte',async()=>{const id=crypto.randomUUID();await rpc('sale',{...payload,request_id:id,items:[{product_id:p1,quantity:1}],discount_percent:0,received:30});await rpc('cash_move',{business_id:b,shift_id:shift,kind:'out',amount:20,reason:'Retiro'});const result=await rpc('close_shift',{business_id:b,shift_id:shift,counted_cash:108});assert.equal(result.expected,110);assert.equal(result.difference,-2);await assert.rejects(rpc('sale',{...payload,request_id:crypto.randomUUID()}),/no está abierta/);assert.equal(await rpc('sale',{...payload,request_id:id}),id);});
test('RLS aísla negocios y bloquea escrituras directas',async()=>{await user(OTHER);const other=await rpc('bootstrap',{name:'Otra tienda',user_name:'Otro'});assert.notEqual(other,b);assert.equal((await db.query('select * from public.products')).rows.length,0);await assert.rejects(rpc('stock',{business_id:b,branch_id:branch,product_id:p1,quantity:3,reason:'Invasión'}),/Sin permiso/);await assert.rejects(db.query('update public.inventory set quantity=100'));await assert.rejects(rpc('product',{business_id:other,category_id:(await db.query('select id from public.categories limit 1')).rows[0].id,sku:'X',name:'X',price:1,cost:0,min_stock:0,id:p1}),/inválido/);await user(ADMIN);});
test('Alta por correo valida rol, evita autoedición y no duplica miembros',async()=>{
const call=email=>db.query('select public.add_member_by_email($1,$2,$3,$4,$5::uuid) result',[b,email,'Personal','cashier',branch]);
assert.equal((await call(' CAJERO@test.com ')).rows[0].result,CASHIER);await call('cajero@test.com');
assert.equal((await db.query('select * from public.members where user_id=$1',[CASHIER])).rows.length,1);
await assert.rejects(call('admin@test.com'),/propio rol/);await assert.rejects(call('noexiste@test.com'),/No existe/);
await user(CASHIER);await assert.rejects(call('otro@test.com'),/Solo administradores/);await user(ADMIN);
});
test('Cajero no administra catálogo, miembros ni cajas ajenas',async()=>{await rpc('member',{business_id:b,user_id:CASHIER,name:'Cajero',role:'cashier',assigned_branch_id:branch});const newShift=await rpc('open_shift',{business_id:b,branch_id:branch,opening_cash:0});await user(CASHIER);await assert.rejects(rpc('product',{business_id:b,sku:'C',name:'C',price:1,cost:0,min_stock:0}),/Solo administradores/);await assert.rejects(rpc('cash_move',{business_id:b,shift_id:newShift,kind:'out',amount:1,reason:'Retiro'}),/otro usuario/);await user(ADMIN);await assert.rejects(rpc('remove_member',{business_id:b,id:ADMIN}),/propio acceso/);await db.close();});
