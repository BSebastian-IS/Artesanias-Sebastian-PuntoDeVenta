import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {shipmentTicket} from '../src/modules/tickets.js';
test('Envío suma destino, guarda partidas y protege reintentos/permisos',async()=>{
const db=new PGlite();const admin='00000000-0000-4000-8000-000000000001',cash='00000000-0000-4000-8000-000000000002',other='00000000-0000-4000-8000-000000000003';
try{
await db.exec(`create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,email text);insert into auth.users values('${admin}','admin@test.com'),('${cash}','cash@test.com'),('${other}','other@test.com');create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('test.uid',true),'')::uuid$$;grant usage on schema auth to authenticated;`);
for(const f of ['01_esquema.sql','02_usuarios_por_correo.sql','03_cajeros_por_sucursal.sql','06_envios_sucursal.sql','06_envios_sucursal.sql'])await db.exec(await readFile(new URL('../supabase/'+f,import.meta.url),'utf8'));
const user=async id=>{await db.exec('reset role');await db.query("select set_config('test.uid',$1,false)",[id]);await db.exec('set role authenticated');};
const rpc=async(a,p)=>(await db.query('select public.pos_action($1,$2::jsonb) r',[a,JSON.stringify(p)])).rows[0].r;
await user(admin);const b=await rpc('bootstrap',{name:'Negocio',user_name:'Administrador'});const brs=(await db.query('select * from public.branches order by name')).rows;const br=brs[0].id,elsewhere=brs[1].id;
const p=await rpc('product',{business_id:b,sku:'ART-1',name:'Producto 1',price:30,cost:10,min_stock:5}),p2=await rpc('product',{business_id:b,sku:'ART-2',name:'Producto 2',price:20,cost:5,min_stock:5});
await rpc('stock',{business_id:b,branch_id:br,product_id:p,quantity:10,reason:'Inicio'});await rpc('stock',{business_id:b,branch_id:elsewhere,product_id:p,quantity:20,reason:'Inicio'});
const send=async(id,items=[{product_id:p,quantity:30},{product_id:p2,quantity:4}],branch=br,notes='Revisar cajas')=>(await db.query('select public.create_shipment($1,$2,$3,$4::jsonb,$5) r',[b,branch,id,JSON.stringify(items),notes])).rows[0].r;
const qty=async(pid,branch=br)=>(await db.query('select quantity from public.inventory where branch_id=$1 and product_id=$2',[branch,pid])).rows[0]?.quantity||0;
const id=crypto.randomUUID();assert.equal(await send(id),id);assert.equal(await qty(p),40);assert.equal(await qty(p2),4);assert.equal(await qty(p,elsewhere),20);
assert.equal(await send(id,[{product_id:p2,quantity:4},{product_id:p,quantity:30}]),id);assert.equal(await qty(p),40);
await assert.rejects(send(id,[{product_id:p,quantity:31}]),/otros datos/);await assert.rejects(send(id,undefined,elsewhere),/otros datos/);
const oldCount=(await db.query('select count(*)::int n from public.shipments')).rows[0].n;
await assert.rejects(send(crypto.randomUUID(),[{product_id:p,quantity:1},{product_id:crypto.randomUUID(),quantity:1}]),/Producto inválido/);assert.equal(await qty(p),40);assert.equal((await db.query('select count(*)::int n from public.shipments')).rows[0].n,oldCount);
for(const bad of [[],[{product_id:p,quantity:0}],[{product_id:p,quantity:-1}],[{product_id:p,quantity:1.5}],[{product_id:p,quantity:1},{product_id:p,quantity:2}]])await assert.rejects(send(crypto.randomUUID(),bad));
await assert.rejects(send(crypto.randomUUID(),undefined,crypto.randomUUID()),/Sucursal/);
await rpc('product',{business_id:b,id:p,sku:'NUEVO',name:'Renombrado',price:99,cost:5,min_stock:5,active:true});assert.equal((await db.query('select name from public.shipment_items where product_id=$1',[p])).rows[0].name,'Producto 1');
await rpc('member',{business_id:b,user_id:cash,name:'Cajero',role:'cashier',assigned_branch_id:br});await send(crypto.randomUUID(),[{product_id:p,quantity:2}],elsewhere);
await user(cash);assert.equal((await db.query('select * from public.shipments')).rows.length,1);assert.equal((await db.query('select * from public.shipment_items')).rows.length,2);await assert.rejects(send(crypto.randomUUID()),/Solo administradores/);await assert.rejects(db.exec('update public.shipments set notes=\'otra\''),/permission denied/);
await user(other);assert.equal((await db.query('select * from public.shipments')).rows.length,0);assert.equal((await db.query('select * from public.shipment_items')).rows.length,0);await assert.rejects(send(crypto.randomUUID()),/Solo administradores/);
await db.exec('reset role;set role anon');await assert.rejects(send(crypto.randomUUID()),/permission denied/);await assert.rejects(db.exec('select * from public.shipments'),/permission denied/);
}finally{await db.close();}
});
test('Ticket contiene cantidades y recepción; escapa nombres y notas',()=>{
const s={business:{name:'Negocio'},db:{shipments:[{id:'x',folio:1,branch_name:'Barra',prepared_by:'Admin',created_at:'2026-10-02T00:00:00Z',notes:'<script>mal</script>'}],shipment_items:[{shipment_id:'x',name:'<img src=x>',sku:'ART-1',quantity:30}]}};
const html=shipmentTicket(s,'x');assert.ok(html.includes('ENV-000001'));assert.ok(html.includes('Recibido'));assert.ok(html.includes('Total de piezas enviadas: 30'));assert.ok(html.includes('Firma de quien recibe'));assert.ok(html.includes('&lt;script&gt;'));assert.ok(!html.includes('<img'));assert.ok(!html.includes('Precio'));
});
