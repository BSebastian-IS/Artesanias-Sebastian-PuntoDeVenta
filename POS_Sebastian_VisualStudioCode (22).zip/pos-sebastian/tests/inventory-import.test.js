import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {prepareInventoryCSV} from '../src/lib/inventory-import.js';
test('CSV valida sucursal, códigos, enteros y duplicados',()=>{
const db={products:[{id:'p1',sku:'ART-1',active:true}]},br={name:'Ambulante'};
assert.deepEqual(prepareInventoryCSV('\uFEFFsku,name,branch,quantity\nART-1,Producto,Ambulante,50',db,br),[{product_id:'p1',quantity:50}]);
for(const row of ['ART-1,x,Otra,50','NO,x,Ambulante,50','ART-1,x,Ambulante,-1','ART-1,x,Ambulante,1.2'])assert.throws(()=>prepareInventoryCSV('sku,name,branch,quantity\n'+row,db,br));
assert.throws(()=>prepareInventoryCSV('sku,branch,quantity\nART-1,Ambulante,50\nART-1,Ambulante,50',db,br),/repetido/);
});
test('Importación inicial: 1629 filas atómicas, permisos y repetición segura',async()=>{
const db=new PGlite();const admin='00000000-0000-4000-8000-000000000001',cash='00000000-0000-4000-8000-000000000002',other='00000000-0000-4000-8000-000000000003';
try{
await db.exec(`create role anon;create role authenticated;create schema auth;create table auth.users(id uuid primary key,email text);insert into auth.users values('${admin}','admin@test.com'),('${cash}','cash@test.com'),('${other}','other@test.com');create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('test.uid',true),'')::uuid$$;grant usage on schema auth to authenticated;`);
for(const file of ['01_esquema.sql','02_usuarios_por_correo.sql','03_cajeros_por_sucursal.sql','05_importar_inventario.sql','05_importar_inventario.sql'])await db.exec(await readFile(new URL('../supabase/'+file,import.meta.url),'utf8'));
const user=async id=>{await db.exec('reset role');await db.query("select set_config('test.uid',$1,false)",[id]);await db.exec('set role authenticated');};
const rpc=async(action,payload)=>(await db.query('select public.pos_action($1,$2::jsonb) result',[action,JSON.stringify(payload)])).rows[0].result;
await user(admin);const b=await rpc('bootstrap',{name:'Negocio'}),br=(await db.query('select id from public.branches limit 1')).rows[0].id;
await db.exec('reset role');
const items=(await db.query(`insert into public.products(business_id,sku,name,price) select $1,'ART-'||n,'Producto '||n,30 from generate_series(1,1629) n returning id`,[b])).rows.map(p=>({product_id:p.id,quantity:50}));
await user(admin);
const load=async(data=items,branch=br)=>(await db.query('select public.import_initial_inventory($1,$2,$3::jsonb) result',[b,branch,JSON.stringify(data)])).rows[0].result;
const bad=[...items.slice(0,1),{product_id:crypto.randomUUID(),quantity:50}];await assert.rejects(load(bad),/Producto/);assert.equal((await db.query('select count(*)::int n from public.inventory')).rows[0].n,0);
assert.deepEqual(await load(),{repeated:false,count:1629});assert.equal((await db.query('select sum(quantity)::int n from public.inventory')).rows[0].n,81450);
await rpc('stock',{business_id:b,branch_id:br,product_id:items[0].product_id,quantity:-1,reason:'Simular salida'});
assert.equal((await load([...items].reverse())).repeated,true);assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[items[0].product_id])).rows[0].quantity,49);
const changed=[{...items[1],quantity:60},{...items[0],quantity:20}];
assert.equal((await load(changed)).repeated,false);
assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[items[1].product_id])).rows[0].quantity,60);
assert.equal((await db.query('select quantity from public.inventory where product_id=$1',[items[0].product_id])).rows[0].quantity,20);
const movements=(await db.query("select quantity from public.stock_movements where reason='Ajuste por importación CSV' and product_id=$1 order by created_at",[items[0].product_id])).rows.map(x=>x.quantity);assert.deepEqual(movements,[50,-29]);
assert.equal((await load(changed)).repeated,true);

await assert.rejects(load([items[0],items[0]]),/repetidos/);
await assert.rejects(load([{...items[0],quantity:-1}]),/Fila/);
await rpc('member',{business_id:b,user_id:cash,name:'Cajero',role:'cashier',assigned_branch_id:br});await user(cash);await assert.rejects(load(),/Solo administradores/);
await user(other);await assert.rejects(load(),/Solo administradores/);
await user(admin);await assert.rejects(load(items,crypto.randomUUID()),/Sucursal/);
await db.exec('reset role;set role anon');await assert.rejects(load(),/permission denied/);
}finally{await db.close();}
});
