-- Actualización para un POS que YA tiene 01_esquema.sql instalado.
-- No borra tablas, ventas ni usuarios. Puede ejecutarse nuevamente.
begin;
create or replace function pos_private.add_member_by_email(b uuid,email_ text,name_ text,role_ text)
returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();target uuid;
begin
if actor is null or not exists(select 1 from public.members where business_id=b and user_id=actor and role='admin') then raise exception 'Solo administradores del negocio';end if;
if role_ not in ('admin','cashier') or role_ is null then raise exception 'Rol inválido';end if;
if nullif(trim(name_),'') is null then raise exception 'Nombre obligatorio';end if;
select id into target from auth.users where lower(email)=lower(trim(email_));
if target is null then raise exception 'No existe una cuenta con ese correo';end if;
if target=actor then raise exception 'Tu cuenta ya tiene acceso. No puedes cambiar tu propio rol';end if;
insert into public.members(business_id,user_id,name,role) values(b,target,trim(name_),role_)
on conflict(business_id,user_id) do update set name=excluded.name,role=excluded.role;
return target;
end;$$;
revoke all on function pos_private.add_member_by_email(uuid,text,text,text) from public,anon;
grant execute on function pos_private.add_member_by_email(uuid,text,text,text) to authenticated;
create or replace function public.add_member_by_email(business_id uuid,email text,name text,role text)
returns uuid language sql security invoker set search_path='' as $$select pos_private.add_member_by_email(business_id,email,name,role);$$;
revoke all on function public.add_member_by_email(uuid,text,text,text) from public,anon;
grant execute on function public.add_member_by_email(uuid,text,text,text) to authenticated;
commit;
