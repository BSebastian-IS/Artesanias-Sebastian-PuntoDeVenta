const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
async function hashPin(pin,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),'PBKDF2',false,['deriveBits']);const bytes=Uint8Array.from(salt.match(/../g),x=>parseInt(x,16));return hex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes,iterations:210000,hash:'SHA-256'},key,256)));}

const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json'}});
// Inyección de dependencias permite probar autorización sin un proyecto remoto.
export function createStaffHandler({createClient,getEnv}){return async req=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 if(req.method!=='POST')return reply(405,{error:'Método no permitido'});
 const auth=req.headers.get('Authorization');
 if(!auth?.startsWith('Bearer '))return reply(401,{error:'Inicia sesión como administrador'});
 try{
  const url=getEnv('SUPABASE_URL'),anon=getEnv('SUPABASE_ANON_KEY'),secret=getEnv('SUPABASE_SERVICE_ROLE_KEY');
  if(!url||!anon||!secret)return reply(500,{error:'Falta configurar la función en Supabase'});
  const caller=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false,autoRefreshToken:false}});
  // getUser verifica el token contra Supabase Auth; no confiamos en datos del formulario.
  const {data:identity,error:authError}=await caller.auth.getUser(auth.slice(7));
  if(authError||!identity.user)return reply(401,{error:'Tu sesión expiró. Vuelve a entrar'});
  let input;try{input=await req.json();}catch{return reply(400,{error:'Solicitud inválida'});}
  const pinMode=input.pin!==undefined;
  if(pinMode){if(!/^\d{4}$/.test(String(input.pin)))return reply(400,{error:'El NIP debe tener 4 dígitos'});input.email=crypto.randomUUID()+'@personal.pos.invalid';input.password=crypto.randomUUID()+crypto.randomUUID();}
  const {business_id,role}=input;const branch_id=role==='cashier'?(input.branch_id||null):null;const email=String(input.email||'').trim().toLowerCase();const name=String(input.name||'').trim();const password=String(input.password||'');
  if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(business_id||'')||!['admin','cashier'].includes(role)||!name||name.length>120||!/^\S+@\S+\.\S+$/.test(email)||email.length>254||password.length<8||password.length>128)return reply(400,{error:'Revisa nombre, correo, rol y contraseña (8 a 128 caracteres)'});
  const {data:member,error:memberError}=await caller.from('members').select('role').eq('business_id',business_id).eq('user_id',identity.user.id).maybeSingle();
  if(memberError||member?.role!=='admin')return reply(403,{error:'Solo administradores del negocio pueden crear cuentas'});
  if(role==='cashier'){
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(branch_id||''))return reply(400,{error:'Selecciona la sucursal del cajero'});
   const {data:branch,error:branchError}=await caller.from('branches').select('id').eq('business_id',business_id).eq('id',branch_id).maybeSingle();
   if(branchError||!branch)return reply(400,{error:'La sucursal no pertenece a este negocio'});
  }
  if(input.branch_ids!==undefined){if(!Array.isArray(input.branch_ids)||input.branch_ids.length>100||(role==='cashier'&&!input.branch_ids.length))return reply(400,{error:'Selecciona entre 1 y 100 puntos de venta'});if(role==='cashier'){for(const id of input.branch_ids){if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id||''))return reply(400,{error:'Sucursal inválida'});const checked=await caller.from('branches').select('id').eq('business_id',business_id).eq('id',id).maybeSingle();if(checked.error||!checked.data)return reply(400,{error:'Una sucursal no pertenece al negocio'});}}}
  // El cliente administrativo existe únicamente en el servidor.
  const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:created,error:createError}=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{display_name:name}});
  if(createError){const existing=['email_exists','email_address_exists','user_already_exists'].includes(createError.code)||/already|registered|exists/i.test(createError.message||'');return reply(400,{error:existing?'Ese correo ya tiene una cuenta. Selecciona «Usar cuenta existente» para agregarla sin cambiar su contraseña.':createError.message||'No se pudo crear la cuenta'});}
  if(!created?.user)return reply(500,{error:'No se pudo confirmar la cuenta. Revisa Authentication antes de reintentar'});
  // El RPC vuelve a validar el rol, incluso si se revocó durante la creación.
  const {error:linkError}=await caller.rpc('add_member_by_email',{business_id,email,name,role,branch_id});
  if(linkError)return reply(409,{error:'La cuenta fue creada, pero falta asociarla al negocio. Usa «Usar cuenta existente» con el mismo correo. '+linkError.message});
  if(Array.isArray(input.branch_ids)){const assigned=await caller.rpc('update_staff',{business_id,user_id:created.user.id,name,role,branch_ids:role==='cashier'?input.branch_ids:[]});if(assigned.error)return reply(409,{error:'Usuario creado. Revisa sus sucursales en Usuarios. '+assigned.error.message});}
  if(pinMode){const salt=Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');const pin_hash=await hashPin(String(input.pin),salt);const saved=await admin.rpc('staff_pin_set',{actor:identity.user.id,b:business_id,target:created.user.id,salt_value:salt,hash_value:pin_hash});if(saved.error)return reply(409,{error:'Usuario creado. Asigna su NIP en Usuarios después de instalar 10_cajeros_varias_sucursales.sql.'});}
  return reply(200,{ok:true,message:'Cuenta y acceso creados'});
 }catch{return reply(500,{error:'No se pudo confirmar la operación. Si la cuenta aparece en Authentication, usa «Usar cuenta existente» con el mismo correo'});}
};}
