// @ts-nocheck
import {createClient} from "npm:@supabase/supabase-js@2.117.2";
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
const response=(status,data)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'no-store'}});
const uuid=x=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x||'');
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
export async function hashPin(pin,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),'PBKDF2',false,['deriveBits']);const bytes=Uint8Array.from(salt.match(/../g),x=>parseInt(x,16));return hex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes,iterations:210000,hash:'SHA-256'},key,256)));}
const equalHash=(a,b)=>{if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;};
export function createPinHandler({createClient,getEnv}){return async req=>{
if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
if(req.method!=='POST')return response(405,{error:'Método no permitido'});
try{
const input=await req.json();const mode=input.action;const pin=String(input.pin||'');const username=String(input.username||'').trim();
if(!['login','set','remove'].includes(mode))return response(400,{error:'Acción inválida'});
if(mode!=='remove'&&!/^\d{4}$/.test(pin))return response(400,{error:'El NIP debe tener exactamente 4 dígitos'});
const url=getEnv('SUPABASE_URL'),anon=getEnv('SUPABASE_ANON_KEY'),secret=getEnv('SUPABASE_SERVICE_ROLE_KEY');if(!url||!anon||!secret)return response(500,{error:'Configura la función staff-pin'});
const admin=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
if(mode!=='login'){
const auth=req.headers.get('Authorization');if(!auth?.startsWith('Bearer '))return response(401,{error:'Inicia sesión como administrador'});
if(!uuid(input.business_id)||!uuid(input.user_id))return response(400,{error:'Usuario inválido'});
const caller=createClient(url,anon,{global:{headers:{Authorization:auth}},auth:{persistSession:false,autoRefreshToken:false}});
const {data,error}=await caller.auth.getUser(auth.slice(7));if(error||!data.user)return response(401,{error:'Sesión inválida'});
const salt=mode==='set'?hex(crypto.getRandomValues(new Uint8Array(16))):null;
const pin_hash=mode==='set'?await hashPin(pin,salt):null;
const result=await admin.rpc('staff_pin_set',{actor:data.user.id,b:input.business_id,target:input.user_id,salt_value:salt,hash_value:pin_hash});
if(result.error)return response(403,{error:result.error.message});return response(200,{ok:true});
}
if(!username||username.length>120||!['admin','cashier'].includes(input.role)||(input.business_id&&!uuid(input.business_id)))return response(400,{error:'Revisa tu nombre de usuario y NIP'});
const deny=()=>response(401,{error:'Usuario o NIP incorrecto, acceso no asignado o intentos agotados. Tras 5 intentos espera 15 minutos.'});
const {data:p,error:readError}=await admin.rpc('staff_pin_begin',{email_value:username,b:input.business_id||null});
if(readError)return response(500,{error:'Revisa SQL 09 y 10 en Supabase'});
if(!p||p.role!==input.role||(input.branch_id&&(!uuid(input.branch_id)||(p.role!=='admin'&&!(p.branch_ids||[p.branch_id]).includes(input.branch_id))))||!equalHash(await hashPin(pin,p.salt),p.pin_hash))return deny();
const email=p.email;
if(input.branch_id&&p.role==='admin'){const branch=await admin.from('branches').select('id').eq('business_id',p.business_id).eq('id',input.branch_id).maybeSingle();if(branch.error||!branch.data)return deny();}
// Auth emite una sesión real: las políticas RLS siguen identificando al cajero.
const link=await admin.auth.admin.generateLink({type:'magiclink',email});
if(link.error||link.data.user?.id!==p.user_id||!link.data.properties?.hashed_token)return deny();
const authClient=createClient(url,anon,{auth:{persistSession:false,autoRefreshToken:false}});
const verified=await authClient.auth.verifyOtp({token_hash:link.data.properties.hashed_token,type:'email'});
if(verified.error||verified.data.user?.id!==p.user_id||!verified.data.session)return deny();
const finished=await admin.rpc('staff_pin_finish',{b:p.business_id,target:p.user_id,v:p.version,email_value:email});
if(finished.error||!finished.data)return deny();
const session=verified.data.session;
return response(200,{ok:true,business_id:p.business_id,branch_id:input.branch_id||p.branch_id,session:{access_token:session.access_token,refresh_token:session.refresh_token}});
}catch{return response(500,{error:'No se pudo completar el acceso. Revisa que staff-pin esté publicada.'});}
};}

Deno.serve(createPinHandler({createClient,getEnv:name=>Deno.env.get(name)}));
