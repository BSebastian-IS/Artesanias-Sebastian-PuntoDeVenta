-- Obsoleto si aplicaste SQL 14: no ejecutar después de 14.
-- Número estable y único por venta. Se asigna al guardar, no al imprimir.
begin;
alter table public.sales add column if not exists ticket_number bigint generated always as identity;
create unique index if not exists sales_ticket_number_unique on public.sales(ticket_number);
commit;
