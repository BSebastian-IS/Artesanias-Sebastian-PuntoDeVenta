-- Después de 03_cajeros_por_sucursal.sql. Puede ejecutarse de nuevo.
begin;
create table if not exists public.shipments(
 id uuid primary key,
 business_id uuid not null references public.businesses,
 branch_id uuid not null,
 folio bigint generated always as identity unique,
 user_id uuid not null references auth.users,
 prepared_by text not null,
 branch_name text not null,
 notes text not null default '',
 request_payload jsonb not null,
 created_at timestamptz not null default now(),
 unique(business_id,id),
 foreign key(business_id,branch_id) references public.branches(business_id,id)
);
create table if not exists public.shipment_items(
 id uuid primary key default gen_random_uuid(),
 business_id uuid not null references public.businesses,
 shipment_id uuid not null,
 product_id uuid not null references public.products,
 sku text not null,
 name text not null,
 quantity integer not null check(quantity>0),
 unique(shipment_id,product_id),
 foreign key(business_id,shipment_id) references public.shipments(business_id,id)
);
create index if not exists shipments_business_branch_idx on public.shipments(business_id,branch_id,created_at desc);
create index if not exists shipment_items_business_shipment_idx on public.shipment_items(business_id,shipment_id);
alter table public.shipments enable row level security;
alter table public.shipment_items enable row level security;
revoke all on public.shipments,public.shipment_items from public,anon,authenticated;
grant select on public.shipments,public.shipment_items to authenticated;
drop policy if exists shipment_read on public.shipments;
create policy shipment_read on public.shipments for select to authenticated using(pos_private.can_branch(business_id,branch_id));
drop policy if exists shipment_items_read on public.shipment_items;
create policy shipment_items_read on public.shipment_items for select to authenticated using(exists(select 1 from public.shipments s where s.id=shipment_id and s.business_id=shipment_items.business_id));
create or replace function pos_private.create_shipment(b uuid,br uuid,request_id uuid,items jsonb,notes text)
returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); who text; dest text; normalized jsonb; payload jsonb; old public.shipments; it jsonb; p public.products; q integer; f bigint;
begin
select name into who from public.members where business_id=b and user_id=u and role='admin' for share;
if not found then raise exception 'Solo administradores pueden preparar envíos';end if;
select name into dest from public.branches where id=br and business_id=b for share;
if not found then raise exception 'Sucursal inválida';end if;
if request_id is null then raise exception 'Folio de solicitud obligatorio';end if;
if items is null or jsonb_typeof(items)<>'array' then raise exception 'Lista de productos inválida';end if;
if jsonb_array_length(items)=0 or jsonb_array_length(items)>1000 then raise exception 'Agrega entre 1 y 1000 productos';end if;
if length(coalesce(notes,''))>1000 then raise exception 'Observaciones demasiado largas';end if;
if exists(select 1 from jsonb_array_elements(items) x where jsonb_typeof(x)<>'object' or x->>'product_id' is null or x->>'quantity' is null or (x->>'quantity')!~'^[0-9]+$' or (x->>'quantity')::numeric<1 or (x->>'quantity')::numeric>2147483647) then raise exception 'Cantidad o producto inválido';end if;
if (select count(distinct (x->>'product_id')::uuid) from jsonb_array_elements(items) x)<>jsonb_array_length(items) then raise exception 'Producto repetido';end if;
select jsonb_agg(jsonb_build_object('product_id',(x->>'product_id')::uuid,'quantity',(x->>'quantity')::integer) order by (x->>'product_id')::uuid) into normalized from jsonb_array_elements(items) x;
payload:=jsonb_build_object('branch_id',br,'items',normalized,'notes',coalesce(notes,''));
-- La clave de solicitud bloquea reintentos concurrentes y evita sumar dos veces.
insert into public.shipments(id,business_id,branch_id,user_id,prepared_by,branch_name,notes,request_payload) values(request_id,b,br,u,who,dest,coalesce(notes,''),payload) on conflict(id) do nothing returning folio into f;
if not found then
select * into old from public.shipments where id=request_id;
if old.business_id is distinct from b or old.user_id is distinct from u or old.request_payload is distinct from payload then raise exception 'Solicitud ya utilizada con otros datos';end if;
return request_id;
end if;
for it in select value from jsonb_array_elements(normalized) loop
select * into p from public.products where id=(it->>'product_id')::uuid and business_id=b and active for share;
if not found then raise exception 'Producto inválido o archivado';end if;
q:=(it->>'quantity')::integer;
insert into public.inventory(business_id,branch_id,product_id,quantity) values(b,br,p.id,0) on conflict(branch_id,product_id) do nothing;
update public.inventory set quantity=quantity+q where business_id=b and branch_id=br and product_id=p.id;
if not found then raise exception 'Inventario inválido';end if;
insert into public.shipment_items(business_id,shipment_id,product_id,sku,name,quantity) values(b,request_id,p.id,p.sku,p.name,q);
insert into public.stock_movements(business_id,branch_id,product_id,user_id,quantity,reason) values(b,br,p.id,u,q,'Envío ENV-'||lpad(f::text,greatest(6,length(f::text)),'0'));
end loop;
return request_id;
end;$$;
create or replace function public.create_shipment(business_id uuid,branch_id uuid,request_id uuid,items jsonb,notes text default '')
returns uuid language sql security invoker set search_path='' as $$select pos_private.create_shipment(business_id,branch_id,request_id,items,notes)$$;
revoke all on function pos_private.create_shipment(uuid,uuid,uuid,jsonb,text) from public,anon;
revoke all on function public.create_shipment(uuid,uuid,uuid,jsonb,text) from public,anon;
grant execute on function pos_private.create_shipment(uuid,uuid,uuid,jsonb,text) to authenticated;
grant execute on function public.create_shipment(uuid,uuid,uuid,jsonb,text) to authenticated;
commit;
