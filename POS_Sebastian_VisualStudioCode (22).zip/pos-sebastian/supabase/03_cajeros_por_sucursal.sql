-- Actualización: ejecutar DESPUÉS de 01 y 02. No borra datos.
-- Cajeros existentes sin sucursal: acceso bloqueado hasta asignación desde Usuarios.
begin;
alter table public.members add column if not exists branch_id uuid;
create unique index if not exists branches_business_id_id_key on public.branches(business_id,id);
do $$begin
if not exists(select 1 from pg_constraint where conrelid='public.members'::regclass and conname='members_assigned_branch_fkey') then
alter table public.members add constraint members_assigned_branch_fkey foreign key(business_id,branch_id) references public.branches(business_id,id);
end if;end$$;
create index if not exists members_branch_id_idx on public.members(branch_id);
create or replace function pos_private.validate_member_branch() returns trigger language plpgsql security definer set search_path='' as $$
begin
if new.role='admin' then new.branch_id:=null;
elsif new.role='cashier' and new.branch_id is null then raise exception 'Selecciona la sucursal del cajero';end if;
if tg_op='UPDATE' and (old.branch_id is distinct from new.branch_id or old.role is distinct from new.role) and exists(select 1 from public.shifts where business_id=old.business_id and user_id=old.user_id and closed_at is null) then raise exception 'Cierra las cajas abiertas de esta persona antes de cambiar su sucursal o rol';end if;
return new;end;$$;
revoke all on function pos_private.validate_member_branch() from public,anon,authenticated;
drop trigger if exists member_branch_validation on public.members;
create trigger member_branch_validation before insert or update on public.members for each row execute function pos_private.validate_member_branch();
create or replace function pos_private.is_admin(b uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.members where business_id=b and user_id=(select auth.uid()) and role='admin');$$;
create or replace function pos_private.can_branch(b uuid,br uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.members m where m.business_id=b and m.user_id=(select auth.uid()) and (m.role='admin' or (m.role='cashier' and m.branch_id is not null and m.branch_id=br)));$$;
create or replace function pos_private.can_catalog(b uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.members where business_id=b and user_id=(select auth.uid()) and (role='admin' or branch_id is not null));$$;
revoke all on function pos_private.is_admin(uuid),pos_private.can_branch(uuid,uuid),pos_private.can_catalog(uuid) from public,anon;
grant execute on function pos_private.is_admin(uuid),pos_private.can_branch(uuid,uuid),pos_private.can_catalog(uuid) to authenticated;
-- Restrictivas: se combinan con la política business_read, no la amplían.
do $$declare t text;predicate text;begin
foreach t in array array['members','branches','categories','products','customers','suppliers','inventory','shifts','sales','sale_items','cash_movements','stock_movements'] loop
predicate:=case
when t='members' then 'pos_private.is_admin(business_id) or user_id=(select auth.uid())'
when t='branches' then 'pos_private.can_branch(business_id,id)'
when t in ('inventory','shifts','sales','stock_movements') then 'pos_private.can_branch(business_id,branch_id)'
when t='sale_items' then 'exists(select 1 from public.sales s where s.id=sale_id and s.business_id=sale_items.business_id)'
when t='cash_movements' then 'exists(select 1 from public.shifts s where s.id=shift_id and s.business_id=cash_movements.business_id)'
when t='suppliers' then 'pos_private.is_admin(business_id)'
else 'pos_private.can_catalog(business_id)' end;
execute format('drop policy if exists branch_scope on public.%I',t);
execute format('create policy branch_scope on public.%I as restrictive for select to authenticated using(%s)',t,predicate);
end loop;end$$;
create or replace function pos_private.perform_action(action text,payload jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();b uuid;r text;assigned uuid;bid uuid;pid uuid;sid uuid;cid uuid;obj uuid;supp uuid;v public.products%rowtype;sh public.shifts%rowtype;s public.sales%rowtype;it jsonb;q integer;delta integer;sub numeric:=0;disc numeric;tax_ numeric;total_ numeric;received_ numeric;expected_ numeric;rate numeric;n integer;t text;
begin
if u is null then raise exception 'Inicia sesión';end if;
if action='bootstrap' then
perform pg_advisory_xact_lock(hashtextextended(u::text,0));
select business_id into b from public.members where user_id=u limit 1;
if b is not null then return to_jsonb(b);end if;
insert into public.businesses(name) values(coalesce(nullif(trim(payload->>'name'),''),'Artesanías Sebastián')) returning id into b;
insert into public.members(business_id,user_id,name,role) values(b,u,coalesce(nullif(trim(payload->>'user_name'),''),'Administrador'),'admin');
insert into public.branches(business_id,name) values(b,'Manzanillo'),(b,'Barra de Navidad'),(b,'Tecomán');
insert into public.categories(business_id,name) values(b,'Llaveros'),(b,'Souvenirs'),(b,'Accesorios');
return to_jsonb(b);end if;
b:=(payload->>'business_id')::uuid;
select role,branch_id into r,assigned from public.members where business_id=b and user_id=u for share;
if r is null then raise exception 'Sin permiso para este negocio';end if;
if r='cashier' and assigned is null then raise exception 'Pide al administrador que te asigne una sucursal';end if;
if action not in ('sale','open_shift','cash_move','close_shift') and r<>'admin' then raise exception 'Solo administradores';end if;
bid:=nullif(payload->>'branch_id','')::uuid;obj:=nullif(payload->>'id','')::uuid;
if bid is not null and not exists(select 1 from public.branches where id=bid and business_id=b) then raise exception 'Sucursal inválida';end if;
if r='cashier' and bid is not null and bid is distinct from assigned then raise exception 'Solo puedes operar en tu sucursal asignada';end if;
if action='product' then
cid:=nullif(payload->>'category_id','')::uuid;
if cid is not null and not exists(select 1 from public.categories where id=cid and business_id=b) then raise exception 'Categoría inválida';end if;
if trim(coalesce(payload->>'name',''))='' or trim(coalesce(payload->>'sku',''))='' then raise exception 'Nombre y código obligatorios';end if;
if obj is null then insert into public.products(business_id,category_id,sku,name,price,cost,min_stock) values(b,cid,trim(payload->>'sku'),trim(payload->>'name'),(payload->>'price')::numeric,(payload->>'cost')::numeric,(payload->>'min_stock')::integer) returning id into obj;
else update public.products set category_id=cid,sku=trim(payload->>'sku'),name=trim(payload->>'name'),price=(payload->>'price')::numeric,cost=(payload->>'cost')::numeric,min_stock=(payload->>'min_stock')::integer,active=coalesce((payload->>'active')::boolean,true) where id=obj and business_id=b;if not found then raise exception 'Producto inválido';end if;end if;
return to_jsonb(obj);
elsif action='archive_product' then update public.products set active=false where id=obj and business_id=b;if not found then raise exception 'Producto inválido';end if;return to_jsonb(obj);
elsif action in ('customer','supplier','category','branch') then
if trim(coalesce(payload->>'name',''))='' then raise exception 'Nombre obligatorio';end if;
t:=case action when 'customer' then 'customers' when 'supplier' then 'suppliers' when 'category' then 'categories' else 'branches' end;
if obj is null then
if action in ('customer','supplier') then execute format('insert into public.%I(business_id,name,phone,email) values($1,$2,$3,$4) returning id',t) into obj using b,trim(payload->>'name'),coalesce(payload->>'phone',''),coalesce(payload->>'email','');
elsif action='branch' then insert into public.branches(business_id,name,address) values(b,trim(payload->>'name'),coalesce(payload->>'address','')) returning id into obj;
else insert into public.categories(business_id,name) values(b,trim(payload->>'name')) returning id into obj;end if;
else
if action in ('customer','supplier') then execute format('update public.%I set name=$1,phone=$2,email=$3 where id=$4 and business_id=$5',t) using trim(payload->>'name'),coalesce(payload->>'phone',''),coalesce(payload->>'email',''),obj,b;
elsif action='branch' then update public.branches set name=trim(payload->>'name'),address=coalesce(payload->>'address','') where id=obj and business_id=b;
else update public.categories set name=trim(payload->>'name') where id=obj and business_id=b;end if;
get diagnostics n=row_count;if n=0 then raise exception 'Registro inválido';end if;end if;
return to_jsonb(obj);
elsif action='stock' then
pid:=(payload->>'product_id')::uuid;delta:=(payload->>'quantity')::integer;supp:=nullif(payload->>'supplier_id','')::uuid;
if bid is null or not exists(select 1 from public.products where id=pid and business_id=b) then raise exception 'Producto o sucursal inválidos';end if;
if supp is not null and not exists(select 1 from public.suppliers where id=supp and business_id=b) then raise exception 'Proveedor inválido';end if;
if delta is null or delta=0 or trim(coalesce(payload->>'reason',''))='' then raise exception 'Cantidad y motivo obligatorios';end if;
insert into public.inventory(business_id,branch_id,product_id,quantity) values(b,bid,pid,0) on conflict(branch_id,product_id) do nothing;
update public.inventory set quantity=quantity+delta where branch_id=bid and product_id=pid and quantity+delta>=0;
if not found then raise exception 'Existencias insuficientes';end if;
insert into public.stock_movements(business_id,branch_id,product_id,supplier_id,user_id,quantity,reason) values(b,bid,pid,supp,u,delta,trim(payload->>'reason'));return jsonb_build_object('ok',true);
elsif action='open_shift' then
if bid is null then raise exception 'Selecciona sucursal';end if;
insert into public.shifts(business_id,branch_id,user_id,opening_cash) values(b,bid,u,(payload->>'opening_cash')::numeric) returning id into sid;return to_jsonb(sid);
elsif action in ('sale','cash_move','close_shift','cancel_sale') then
if action='cancel_sale' then select * into s from public.sales where id=obj and business_id=b;if not found then raise exception 'Venta inválida';end if;sid:=s.shift_id;else sid:=(payload->>'shift_id')::uuid;end if;
select * into sh from public.shifts where id=sid and business_id=b for update;
if not found then raise exception 'Caja inválida';end if;
if r='cashier' and sh.branch_id is distinct from assigned then raise exception 'Solo puedes operar en tu sucursal asignada';end if;
if r<>'admin' and sh.user_id<>u then raise exception 'La caja pertenece a otro usuario';end if;
-- Idempotencia: incluso si se cerró la caja después de guardar una venta.
if action='sale' then obj:=(payload->>'request_id')::uuid;select * into s from public.sales where id=obj;
if found then if s.business_id<>b or s.shift_id<>sid or s.user_id<>u then raise exception 'Venta inválida';end if;return to_jsonb(obj);end if;end if;
if sh.closed_at is not null then raise exception 'La caja no está abierta';end if;
if action='cash_move' then insert into public.cash_movements(business_id,shift_id,user_id,kind,amount,reason) values(b,sid,u,payload->>'kind',(payload->>'amount')::numeric,coalesce(nullif(trim(payload->>'reason'),''),'Movimiento de caja'));return jsonb_build_object('ok',true);
elsif action='close_shift' then
select sh.opening_cash+coalesce((select sum(total) from public.sales where shift_id=sid and status='paid' and payment='cash'),0)+coalesce((select sum(case when kind='in' then amount else -amount end) from public.cash_movements where shift_id=sid),0) into expected_;
if (payload->>'counted_cash')::numeric<0 or payload->>'counted_cash' is null then raise exception 'Conteo inválido';end if;
update public.shifts set closed_at=now(),expected_cash=expected_,counted_cash=(payload->>'counted_cash')::numeric,difference=(payload->>'counted_cash')::numeric-expected_ where id=sid;
return jsonb_build_object('expected',expected_,'difference',(payload->>'counted_cash')::numeric-expected_);
elsif action='cancel_sale' then
select * into s from public.sales where id=obj and business_id=b for update;if s.status='cancelled' then return to_jsonb(obj);end if;
for it in select to_jsonb(si) from public.sale_items si where sale_id=obj order by product_id loop
update public.inventory set quantity=quantity+(it->>'quantity')::integer where branch_id=s.branch_id and product_id=(it->>'product_id')::uuid;
insert into public.stock_movements(business_id,branch_id,product_id,user_id,quantity,reason) values(b,s.branch_id,(it->>'product_id')::uuid,u,(it->>'quantity')::integer,'Cancelación '||left(obj::text,8));end loop;
update public.sales set status='cancelled' where id=obj;return to_jsonb(obj);end if;
if bid is distinct from sh.branch_id then raise exception 'Sucursal y caja no coinciden';end if;
cid:=nullif(payload->>'customer_id','')::uuid;if cid is not null and not exists(select 1 from public.customers where id=cid and business_id=b) then raise exception 'Cliente inválido';end if;
if jsonb_typeof(payload->'items') is distinct from 'array' then raise exception 'Carrito inválido';end if;
if jsonb_array_length(payload->'items')=0 then raise exception 'Carrito vacío';end if;
select count(distinct value->>'product_id') into n from jsonb_array_elements(payload->'items');if n<>jsonb_array_length(payload->'items') then raise exception 'Productos duplicados';end if;
for it in select value from jsonb_array_elements(payload->'items') order by value->>'product_id' loop
pid:=(it->>'product_id')::uuid;q:=(it->>'quantity')::integer;if q is null or q<=0 then raise exception 'Cantidad inválida';end if;
select * into v from public.products where id=pid and business_id=b and active for share;if not found then raise exception 'Producto no disponible';end if;
update public.inventory set quantity=quantity-q where branch_id=bid and product_id=pid and quantity>=q;if not found then raise exception 'Existencias insuficientes para %',v.name;end if;sub:=sub+v.price*q;end loop;
rate:=coalesce((payload->>'discount_percent')::numeric,0);if rate<0 or rate>100 then raise exception 'Descuento inválido';end if;
disc:=round(sub*rate/100,2);select round((sub-disc)*tax_rate/100,2) into tax_ from public.businesses where id=b;total_:=sub-disc+tax_;
if payload->>'payment' is null or payload->>'payment' not in ('cash','card','transfer') then raise exception 'Pago inválido';end if;
received_:=case when payload->>'payment'='cash' then (payload->>'received')::numeric else total_ end;if received_ is null or received_<total_ then raise exception 'Pago insuficiente';end if;
insert into public.sales(id,business_id,branch_id,shift_id,user_id,customer_id,subtotal,discount,tax,total,payment,received,change) values(obj,b,bid,sid,u,cid,sub,disc,tax_,total_,payload->>'payment',received_,received_-total_);
for it in select value from jsonb_array_elements(payload->'items') loop
select * into v from public.products where id=(it->>'product_id')::uuid;q:=(it->>'quantity')::integer;
insert into public.sale_items(business_id,sale_id,product_id,name,sku,quantity,price,cost) values(b,obj,v.id,v.name,v.sku,q,v.price,v.cost);
insert into public.stock_movements(business_id,branch_id,product_id,user_id,quantity,reason) values(b,bid,v.id,u,-q,'Venta '||left(obj::text,8));end loop;return to_jsonb(obj);
elsif action='member' then
obj:=(payload->>'user_id')::uuid;if obj=u then raise exception 'No puedes cambiar tu propio rol';end if;
insert into public.members(business_id,user_id,name,role,branch_id) values(b,obj,trim(payload->>'name'),payload->>'role',case when payload->>'role'='cashier' then nullif(payload->>'assigned_branch_id','')::uuid else null end) on conflict(business_id,user_id) do update set name=excluded.name,role=excluded.role,branch_id=excluded.branch_id;return to_jsonb(obj);
elsif action='remove_member' then if obj=u then raise exception 'No puedes eliminar tu propio acceso';end if;delete from public.members where business_id=b and user_id=obj;return jsonb_build_object('ok',true);
elsif action='settings' then
if trim(coalesce(payload->>'name',''))='' then raise exception 'Nombre obligatorio';end if;
update public.businesses set name=trim(payload->>'name'),phone=coalesce(payload->>'phone',''),address=coalesce(payload->>'address',''),tax_rate=(payload->>'tax_rate')::numeric where id=b;return to_jsonb(b);
end if;
raise exception 'Acción desconocida';end;$$;
create or replace function pos_private.add_member_by_email(b uuid,email_ text,name_ text,role_ text,branch_ uuid)
returns uuid language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid();target uuid;actor_role text;
begin
select role into actor_role from public.members where business_id=b and user_id=actor for share;
if actor is null or actor_role is distinct from 'admin' then raise exception 'Solo administradores del negocio';end if;
if role_ not in ('admin','cashier') or role_ is null then raise exception 'Rol inválido';end if;
if nullif(trim(name_),'') is null then raise exception 'Nombre obligatorio';end if;
if role_='cashier' and (branch_ is null or not exists(select 1 from public.branches where id=branch_ and business_id=b)) then raise exception 'Selecciona una sucursal válida para el cajero';end if;
select id into target from auth.users where lower(email)=lower(trim(email_));
if target is null then raise exception 'No existe una cuenta con ese correo';end if;
if target=actor then raise exception 'Tu cuenta ya tiene acceso. No puedes cambiar tu propio rol';end if;
insert into public.members(business_id,user_id,name,role,branch_id) values(b,target,trim(name_),role_,case when role_='cashier' then branch_ else null end)
on conflict(business_id,user_id) do update set name=excluded.name,role=excluded.role,branch_id=excluded.branch_id;
return target;end;$$;
revoke all on function pos_private.add_member_by_email(uuid,text,text,text,uuid) from public,anon;
grant execute on function pos_private.add_member_by_email(uuid,text,text,text,uuid) to authenticated;
create or replace function public.add_member_by_email(business_id uuid,email text,name text,role text,branch_id uuid)
returns uuid language sql security invoker set search_path='' as $$select pos_private.add_member_by_email(business_id,email,name,role,branch_id);$$;
revoke all on function public.add_member_by_email(uuid,text,text,text,uuid) from public,anon;
grant execute on function public.add_member_by_email(uuid,text,text,text,uuid) to authenticated;
-- Clientes anteriores no pueden dar acceso ilimitado a un cajero.
create or replace function pos_private.add_member_by_email(b uuid,email_ text,name_ text,role_ text)
returns uuid language sql security invoker set search_path='' as $$select pos_private.add_member_by_email(b,email_,name_,role_,null::uuid);$$;
commit;
