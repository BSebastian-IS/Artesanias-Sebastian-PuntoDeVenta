-- Acceso por nombre de usuario y NIP para administradores y cajeros. Requiere 03_cajeros_por_sucursal.sql.
begin;
create table if not exists pos_private.staff_pins(
 business_id uuid not null references public.businesses,
 user_id uuid not null references auth.users,
 salt text not null,
 pin_hash text not null,
 version uuid not null default gen_random_uuid(),
 attempts integer not null default 0,
 window_start timestamptz not null default now(),
 primary key(business_id,user_id)
);
alter table pos_private.staff_pins enable row level security;
revoke all on pos_private.staff_pins from public,anon,authenticated;
create or replace function pos_private.staff_pin_set(actor uuid,b uuid,target uuid,salt_value text,hash_value text)
returns boolean language plpgsql security definer set search_path='' as $$begin
perform 1 from public.members where business_id=b and user_id=actor and role='admin' for share;
if not found then raise exception 'Solo administradores';end if;
perform 1 from public.members where business_id=b and user_id=target and (role='admin' or (role='cashier' and branch_id is not null)) for share;
if not found then raise exception 'Usuario sin acceso o cajero sin sucursal';end if;
if salt_value is null and hash_value is null then delete from pos_private.staff_pins where business_id=b and user_id=target;return true;end if;
if exists(select 1 from public.members m join pos_private.staff_pins p on p.business_id=m.business_id and p.user_id=m.user_id where lower(trim(m.name))=(select lower(trim(name)) from public.members where business_id=b and user_id=target) and (m.business_id,m.user_id)<>(b,target)) then raise exception 'Ese nombre de usuario ya tiene NIP. Usa un nombre diferente';end if;
if salt_value is null or hash_value is null or salt_value!~'^[0-9a-f]{32}$' or hash_value!~'^[0-9a-f]{64}$' then raise exception 'NIP inválido';end if;
insert into pos_private.staff_pins(business_id,user_id,salt,pin_hash) values(b,target,salt_value,hash_value)
on conflict(business_id,user_id) do update set salt=excluded.salt,pin_hash=excluded.pin_hash,version=gen_random_uuid(),attempts=0,window_start=now();
return true;end;$$;
create or replace function pos_private.staff_pin_begin(email_value text,b uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare found_pin pos_private.staff_pins; n integer;begin
select count(*) into n from pos_private.staff_pins p join auth.users u on u.id=p.user_id join public.members m on m.business_id=p.business_id and m.user_id=p.user_id where lower(trim(m.name))=lower(trim(email_value)) and (b is null or p.business_id=b) and (m.role='admin' or (m.role='cashier' and m.branch_id is not null));
if n<>1 then return null;end if;
select p.* into found_pin from pos_private.staff_pins p join auth.users u on u.id=p.user_id join public.members m on m.business_id=p.business_id and m.user_id=p.user_id where lower(trim(m.name))=lower(trim(email_value)) and (b is null or p.business_id=b) and (m.role='admin' or (m.role='cashier' and m.branch_id is not null)) for update of p;
if not found then return null;end if;
if found_pin.window_start<=now()-interval '15 minutes' then found_pin.attempts:=0;found_pin.window_start:=now();end if;
if found_pin.attempts>=5 then return null;end if;
update pos_private.staff_pins set attempts=found_pin.attempts+1,window_start=found_pin.window_start where business_id=found_pin.business_id and user_id=found_pin.user_id;
return jsonb_build_object('business_id',found_pin.business_id,'user_id',found_pin.user_id,'version',found_pin.version,'salt',found_pin.salt,'pin_hash',found_pin.pin_hash,'email',(select email from auth.users where id=found_pin.user_id),'branch_id',(select branch_id from public.members where business_id=found_pin.business_id and user_id=found_pin.user_id),'role',(select role from public.members where business_id=found_pin.business_id and user_id=found_pin.user_id));
end;$$;
create or replace function pos_private.staff_pin_finish(b uuid,target uuid,v uuid,email_value text)
returns boolean language plpgsql security definer set search_path='' as $$begin
perform 1 from public.members m join auth.users u on u.id=m.user_id where m.business_id=b and m.user_id=target and (m.role='admin' or (m.role='cashier' and m.branch_id is not null)) and lower(u.email)=lower(trim(email_value)) for share of m;
if not found then return false;end if;
update pos_private.staff_pins set attempts=0,window_start=now() where business_id=b and user_id=target and version=v;
return found;end;$$;
create or replace function public.staff_pin_set(actor uuid,b uuid,target uuid,salt_value text,hash_value text) returns boolean language sql security invoker set search_path='' as $$select pos_private.staff_pin_set(actor,b,target,salt_value,hash_value)$$;
create or replace function public.staff_pin_begin(email_value text,b uuid default null) returns jsonb language sql security invoker set search_path='' as $$select pos_private.staff_pin_begin(email_value,b)$$;
create or replace function public.staff_pin_finish(b uuid,target uuid,v uuid,email_value text) returns boolean language sql security invoker set search_path='' as $$select pos_private.staff_pin_finish(b,target,v,email_value)$$;
revoke all on function pos_private.staff_pin_set(uuid,uuid,uuid,text,text),pos_private.staff_pin_begin(text,uuid),pos_private.staff_pin_finish(uuid,uuid,uuid,text) from public,anon,authenticated;
revoke all on function public.staff_pin_set(uuid,uuid,uuid,text,text),public.staff_pin_begin(text,uuid),public.staff_pin_finish(uuid,uuid,uuid,text) from public,anon,authenticated;
grant usage on schema pos_private to service_role;
grant execute on function pos_private.staff_pin_set(uuid,uuid,uuid,text,text),pos_private.staff_pin_begin(text,uuid),pos_private.staff_pin_finish(uuid,uuid,uuid,text) to service_role;
grant execute on function public.staff_pin_set(uuid,uuid,uuid,text,text),public.staff_pin_begin(text,uuid),public.staff_pin_finish(uuid,uuid,uuid,text) to service_role;
-- El estado de NIP es visible al administrador; nunca se devuelve el NIP ni su hash.
create or replace function pos_private.staff_pin_status(b uuid) returns jsonb language plpgsql security definer set search_path='' as $$begin
if not pos_private.is_admin(b) then raise exception 'Solo administradores';end if;
return coalesce((select jsonb_agg(p.user_id) from pos_private.staff_pins p join public.members m on m.business_id=p.business_id and m.user_id=p.user_id where p.business_id=b ),'[]'::jsonb);end;$$;
create or replace function public.staff_pin_status(b uuid) returns jsonb language sql security invoker set search_path='' as $$select pos_private.staff_pin_status(b)$$;
revoke all on function public.staff_pin_status(uuid),pos_private.staff_pin_status(uuid) from public,anon;
grant execute on function public.staff_pin_status(uuid),pos_private.staff_pin_status(uuid) to authenticated;
-- Revoca el NIP cuando se quita el acceso, cambia el rol o se reasigna sucursal.
create or replace function pos_private.revoke_changed_pin() returns trigger language plpgsql security definer set search_path='' as $$begin
if tg_op='DELETE' or old.role is distinct from new.role or old.branch_id is distinct from new.branch_id then delete from pos_private.staff_pins where business_id=old.business_id and user_id=old.user_id;end if;return old;end;$$;
revoke all on function pos_private.revoke_changed_pin() from public,anon,authenticated;
drop trigger if exists member_pin_revoke on public.members;
create trigger member_pin_revoke after delete or update on public.members for each row execute function pos_private.revoke_changed_pin();
commit;

-- Logo privado del negocio. No cambia inventario ni ventas.
begin;
alter table public.businesses add column if not exists logo_path text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('business-logos','business-logos',false,1048576,array['image/webp'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
create or replace function pos_private.logo_access(path_ text,write_ boolean) returns boolean language plpgsql stable security definer set search_path='' as $$
declare b uuid;begin
if auth.uid() is null or path_ is null or path_ !~ '^[0-9a-f-]{36}/[0-9a-f-]{36}[.]webp$' then return false;end if;
b:=split_part(path_,'/',1)::uuid;
return exists(select 1 from public.members m join public.businesses biz on biz.id=m.business_id where m.business_id=b and m.user_id=(select auth.uid()) and (m.role='admin' or (not write_ and m.role='cashier' and m.branch_id is not null and biz.logo_path=path_)));
exception when invalid_text_representation then return false;end;$$;
revoke all on function pos_private.logo_access(text,boolean) from public,anon;
grant execute on function pos_private.logo_access(text,boolean) to authenticated;
drop policy if exists pos_logos_read on storage.objects;
drop policy if exists pos_logos_insert on storage.objects;
drop policy if exists pos_logos_delete on storage.objects;
create policy pos_logos_read on storage.objects for select to authenticated using(bucket_id='business-logos' and pos_private.logo_access(name,false));
create policy pos_logos_insert on storage.objects for insert to authenticated with check(bucket_id='business-logos' and pos_private.logo_access(name,true));
create policy pos_logos_delete on storage.objects for delete to authenticated using(bucket_id='business-logos' and pos_private.logo_access(name,true));
drop policy if exists pos_logos_read_guard on storage.objects;
drop policy if exists pos_logos_insert_guard on storage.objects;
drop policy if exists pos_logos_delete_guard on storage.objects;
drop policy if exists pos_logos_update_guard on storage.objects;
create policy pos_logos_read_guard on storage.objects as restrictive for select to public using(bucket_id<>'business-logos' or pos_private.logo_access(name,false));
create policy pos_logos_insert_guard on storage.objects as restrictive for insert to public with check(bucket_id<>'business-logos' or pos_private.logo_access(name,true));
create policy pos_logos_delete_guard on storage.objects as restrictive for delete to public using(bucket_id<>'business-logos' or pos_private.logo_access(name,true));
create policy pos_logos_update_guard on storage.objects as restrictive for update to public using(bucket_id<>'business-logos') with check(bucket_id<>'business-logos');
create or replace function pos_private.set_business_logo(b uuid,path_ text) returns jsonb language plpgsql security definer set search_path='' as $$begin
perform 1 from public.members where business_id=b and user_id=(select auth.uid()) and role='admin' for share;
if not found then raise exception 'Solo administradores del negocio';end if;
perform 1 from public.businesses where id=b for update;
if not found then raise exception 'Negocio inválido';end if;
if path_ is not null and (not pos_private.logo_access(path_,true) or split_part(path_,'/',1)<>b::text or not exists(select 1 from storage.objects where bucket_id='business-logos' and name=path_)) then raise exception 'Logo inválido o no subido';end if;
update public.businesses set logo_path=path_ where id=b;
return jsonb_build_object('ok',true);end;$$;
revoke all on function pos_private.set_business_logo(uuid,text) from public,anon;
grant execute on function pos_private.set_business_logo(uuid,text) to authenticated;
create or replace function public.set_business_logo(business_id uuid,logo_path text) returns jsonb language sql security invoker set search_path='' as $$select pos_private.set_business_logo(business_id,logo_path)$$;
revoke all on function public.set_business_logo(uuid,text) from public,anon;
grant execute on function public.set_business_logo(uuid,text) to authenticated;
commit;
