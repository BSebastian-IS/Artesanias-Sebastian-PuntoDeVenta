-- Ejecutar solo esta actualización en un proyecto existente.
begin;
create table if not exists pos_private.initial_inventory_imports(
 business_id uuid not null references public.businesses,
 branch_id uuid not null references public.branches,
 fingerprint text not null,
 user_id uuid not null references auth.users,
 created_at timestamptz not null default now(),
 primary key(business_id,branch_id,fingerprint)
);
alter table pos_private.initial_inventory_imports enable row level security;
revoke all on pos_private.initial_inventory_imports from public,anon,authenticated;
create or replace function pos_private.import_initial_inventory(b uuid,br uuid,items jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); fp text; it jsonb; pid uuid; q integer; old_q integer; n integer;
begin
if u is null then raise exception 'Inicia sesión';end if;
perform 1 from public.members where business_id=b and user_id=u and role='admin' for share;
if not found then raise exception 'Solo administradores';end if;
perform 1 from public.branches where id=br and business_id=b for share;
if not found then raise exception 'Sucursal inválida';end if;
if items is null or jsonb_typeof(items)<>'array' then raise exception 'Archivo inválido';end if;
n:=jsonb_array_length(items);if n=0 or n>10000 then raise exception 'Cantidad de filas inválida';end if;
if exists(select 1 from jsonb_array_elements(items) x where jsonb_typeof(x)<>'object' or x->>'product_id' is null or x->>'quantity' is null or (x->>'quantity')!~'^[0-9]+$') then raise exception 'Fila inválida';end if;
if (select count(distinct (x->>'product_id')::uuid) from jsonb_array_elements(items) x)<>n then raise exception 'Productos repetidos';end if;
-- Canonicaliza para reconocer el mismo archivo aunque se reordenen sus filas.
select md5(jsonb_agg(jsonb_build_object('product_id',(x->>'product_id')::uuid,'quantity',(x->>'quantity')::integer) order by (x->>'product_id')::uuid)::text) into fp from jsonb_array_elements(items) x;
insert into pos_private.initial_inventory_imports(business_id,branch_id,fingerprint,user_id) values(b,br,fp,u) on conflict do nothing;
if not found then return jsonb_build_object('repeated',true,'count',n);end if;
for it in select value from jsonb_array_elements(items) order by (value->>'product_id')::uuid loop
pid:=(it->>'product_id')::uuid;q:=(it->>'quantity')::integer;
perform 1 from public.products where id=pid and business_id=b and active for share;
if not found then raise exception 'Producto inexistente, archivado o de otro negocio';end if;
insert into public.inventory(business_id,branch_id,product_id,quantity) values(b,br,pid,0) on conflict(branch_id,product_id) do nothing;
select quantity into old_q from public.inventory where business_id=b and branch_id=br and product_id=pid for update;
if not found then raise exception 'Inventario inválido';end if;
if old_q<>q then
update public.inventory set quantity=q where business_id=b and branch_id=br and product_id=pid;
insert into public.stock_movements(business_id,branch_id,product_id,user_id,quantity,reason) values(b,br,pid,u,q-old_q,'Ajuste por importación CSV');
end if;
end loop;
return jsonb_build_object('repeated',false,'count',n);
end;$$;
create or replace function public.import_initial_inventory(business_id uuid,branch_id uuid,items jsonb)
returns jsonb language sql security invoker set search_path='' as $$select pos_private.import_initial_inventory(business_id,branch_id,items)$$;
revoke all on function pos_private.import_initial_inventory(uuid,uuid,jsonb) from public,anon;
revoke all on function public.import_initial_inventory(uuid,uuid,jsonb) from public,anon;
grant execute on function pos_private.import_initial_inventory(uuid,uuid,jsonb) to authenticated;
grant execute on function public.import_initial_inventory(uuid,uuid,jsonb) to authenticated;
commit;
