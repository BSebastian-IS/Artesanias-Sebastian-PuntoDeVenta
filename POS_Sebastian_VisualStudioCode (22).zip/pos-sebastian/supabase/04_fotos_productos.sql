-- Ejecuta después de 01, 02 y 03. No elimina productos ni datos.
begin;
alter table public.products add column if not exists photo_path text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('product-photos','product-photos',false,5242880,array['image/webp'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
create or replace function pos_private.photo_access(path_ text,write_ boolean) returns boolean language plpgsql stable security definer set search_path='' as $$
declare b uuid;p uuid;begin
if auth.uid() is null or path_ is null or path_ !~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/[0-9a-f-]{36}[.]webp$' then return false;end if;
b:=split_part(path_,'/',1)::uuid;p:=split_part(path_,'/',2)::uuid;
return exists(select 1 from public.members m join public.products prod on prod.business_id=m.business_id where m.business_id=b and m.user_id=(select auth.uid()) and prod.id=p and (m.role='admin' or (not write_ and m.role='cashier' and m.branch_id is not null and prod.photo_path=path_)));
exception when invalid_text_representation then return false;end;$$;
revoke all on function pos_private.photo_access(text,boolean) from public,anon;
grant execute on function pos_private.photo_access(text,boolean) to authenticated;
drop policy if exists pos_photos_read on storage.objects;
drop policy if exists pos_photos_insert on storage.objects;
drop policy if exists pos_photos_delete on storage.objects;
create policy pos_photos_read on storage.objects for select to authenticated using(bucket_id='product-photos' and pos_private.photo_access(name,false));
create policy pos_photos_insert on storage.objects for insert to authenticated with check(bucket_id='product-photos' and pos_private.photo_access(name,true));
create policy pos_photos_delete on storage.objects for delete to authenticated using(bucket_id='product-photos' and pos_private.photo_access(name,true));
-- Restrictivas para que otras políticas amplias no abran este bucket.
drop policy if exists pos_photos_read_guard on storage.objects;
drop policy if exists pos_photos_insert_guard on storage.objects;
drop policy if exists pos_photos_delete_guard on storage.objects;
drop policy if exists pos_photos_update_guard on storage.objects;
create policy pos_photos_read_guard on storage.objects as restrictive for select to public using(bucket_id<>'product-photos' or pos_private.photo_access(name,false));
create policy pos_photos_insert_guard on storage.objects as restrictive for insert to public with check(bucket_id<>'product-photos' or pos_private.photo_access(name,true));
create policy pos_photos_delete_guard on storage.objects as restrictive for delete to public using(bucket_id<>'product-photos' or pos_private.photo_access(name,true));
create policy pos_photos_update_guard on storage.objects as restrictive for update to public using(bucket_id<>'product-photos') with check(bucket_id<>'product-photos');
create or replace function pos_private.set_product_photo(b uuid,p uuid,path_ text) returns jsonb language plpgsql security definer set search_path='' as $$
declare actor_role text;begin
select role into actor_role from public.members where business_id=b and user_id=(select auth.uid()) for share;
if actor_role is distinct from 'admin' then raise exception 'Solo administradores del negocio';end if;
perform 1 from public.products where id=p and business_id=b for update;if not found then raise exception 'Producto inválido';end if;
if path_ is not null and (not pos_private.photo_access(path_,true) or split_part(path_,'/',1)<>b::text or split_part(path_,'/',2)<>p::text or not exists(select 1 from storage.objects where bucket_id='product-photos' and name=path_)) then raise exception 'Foto inválida o no subida';end if;
update public.products set photo_path=path_ where id=p and business_id=b;
return jsonb_build_object('ok',true);end;$$;
revoke all on function pos_private.set_product_photo(uuid,uuid,text) from public,anon;
grant execute on function pos_private.set_product_photo(uuid,uuid,text) to authenticated;
create or replace function public.set_product_photo(business_id uuid,product_id uuid,photo_path text) returns jsonb language sql security invoker set search_path='' as $$select pos_private.set_product_photo(business_id,product_id,photo_path);$$;
revoke all on function public.set_product_photo(uuid,uuid,text) from public,anon;
grant execute on function public.set_product_photo(uuid,uuid,text) to authenticated;
commit;
