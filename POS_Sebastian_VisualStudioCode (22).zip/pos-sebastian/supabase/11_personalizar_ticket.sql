-- Personalización del ticket por negocio. No modifica importes ni ventas.
begin;
alter table public.businesses add column if not exists receipt_settings jsonb not null default '{}'::jsonb;
create or replace function pos_private.set_receipt_settings(b uuid,settings_ jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare v jsonb;k text;begin
perform 1 from public.members where business_id=b and user_id=(select auth.uid()) and role='admin' for share;
if not found then raise exception 'Solo administradores del negocio';end if;
if settings_ is null or jsonb_typeof(settings_)<>'object' then raise exception 'Configuración inválida';end if;
if exists(select 1 from jsonb_object_keys(settings_) as fields(key) where not fields.key=any(array['paper_width','font_size','show_logo','show_address','show_phone','show_cashier','show_customer','show_sku','header_text','footer_text','extra_text'])) then raise exception 'Opción desconocida';end if;
v:='{"paper_width":80,"font_size":12,"show_logo":true,"show_address":true,"show_phone":true,"show_cashier":true,"show_customer":true,"show_sku":false,"header_text":"","footer_text":"¡Gracias por tu compra!","extra_text":""}'::jsonb||settings_;
if jsonb_typeof(v->'paper_width')<>'number' or v->>'paper_width' not in ('58','80') or jsonb_typeof(v->'font_size')<>'number' or v->>'font_size' not in ('11','12','14') then raise exception 'Papel o letra inválidos';end if;
foreach k in array array['show_logo','show_address','show_phone','show_cashier','show_customer','show_sku'] loop if jsonb_typeof(v->k)<>'boolean' then raise exception 'Opción inválida';end if;end loop;
foreach k in array array['header_text','footer_text','extra_text'] loop if jsonb_typeof(v->k)<>'string' or length(v->>k)>(case when k='extra_text' then 500 else 200 end) then raise exception 'Texto demasiado largo o inválido';end if;end loop;
update public.businesses set receipt_settings=v where id=b;
return v;end;$$;
revoke all on function pos_private.set_receipt_settings(uuid,jsonb) from public,anon;
grant execute on function pos_private.set_receipt_settings(uuid,jsonb) to authenticated;
create or replace function public.set_receipt_settings(business_id uuid,settings jsonb) returns jsonb language sql security invoker set search_path='' as $$select pos_private.set_receipt_settings(business_id,settings)$$;
revoke all on function public.set_receipt_settings(uuid,jsonb) from public,anon;
grant execute on function public.set_receipt_settings(uuid,jsonb) to authenticated;
commit;
